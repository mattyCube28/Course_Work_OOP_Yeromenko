﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Course_Work_OOP_Yeromenko
{
    public class Gang
    {
        public string Name { get; set; }
        public string Country { get; set; }
    }
}
