﻿namespace Course_Work_OOP_Yeromenko
{
    partial class CriminalForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            txtGang = new TextBox();
            cmbProfession = new ComboBox();
            dtpBirthDate = new DateTimePicker();
            txtCaseStatus = new TextBox();
            txtLanguages = new TextBox();
            txtDistinctiveMarks = new TextBox();
            txtLastAddress = new TextBox();
            txtBirthPlace = new TextBox();
            txtCitizenship = new TextBox();
            txtHairColor = new TextBox();
            txtEyeColor = new TextBox();
            txtHeight = new TextBox();
            txtNickname = new TextBox();
            txtFirstName = new TextBox();
            txtLastName = new TextBox();
            label15 = new Label();
            label14 = new Label();
            label13 = new Label();
            label12 = new Label();
            label11 = new Label();
            label10 = new Label();
            label9 = new Label();
            label8 = new Label();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            btnSave = new Button();
            btnCancel = new Button();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(txtGang);
            groupBox1.Controls.Add(cmbProfession);
            groupBox1.Controls.Add(dtpBirthDate);
            groupBox1.Controls.Add(txtCaseStatus);
            groupBox1.Controls.Add(txtLanguages);
            groupBox1.Controls.Add(txtDistinctiveMarks);
            groupBox1.Controls.Add(txtLastAddress);
            groupBox1.Controls.Add(txtBirthPlace);
            groupBox1.Controls.Add(txtCitizenship);
            groupBox1.Controls.Add(txtHairColor);
            groupBox1.Controls.Add(txtEyeColor);
            groupBox1.Controls.Add(txtHeight);
            groupBox1.Controls.Add(txtNickname);
            groupBox1.Controls.Add(txtFirstName);
            groupBox1.Controls.Add(txtLastName);
            groupBox1.Controls.Add(label15);
            groupBox1.Controls.Add(label14);
            groupBox1.Controls.Add(label13);
            groupBox1.Controls.Add(label12);
            groupBox1.Controls.Add(label11);
            groupBox1.Controls.Add(label10);
            groupBox1.Controls.Add(label9);
            groupBox1.Controls.Add(label8);
            groupBox1.Controls.Add(label7);
            groupBox1.Controls.Add(label6);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Font = new Font("Yu Gothic UI", 11F, FontStyle.Regular, GraphicsUnit.Point, 204);
            groupBox1.Location = new Point(38, 5);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(843, 734);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Criminal";
            groupBox1.Enter += groupBox1_Enter;
            // 
            // txtGang
            // 
            txtGang.Location = new Point(162, 679);
            txtGang.Multiline = true;
            txtGang.Name = "txtGang";
            txtGang.Size = new Size(647, 32);
            txtGang.TabIndex = 32;
            // 
            // cmbProfession
            // 
            cmbProfession.Font = new Font("Yu Gothic UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 204);
            cmbProfession.FormattingEnabled = true;
            cmbProfession.Location = new Point(162, 488);
            cmbProfession.Name = "cmbProfession";
            cmbProfession.Size = new Size(646, 33);
            cmbProfession.TabIndex = 31;
            // 
            // dtpBirthDate
            // 
            dtpBirthDate.CalendarFont = new Font("Yu Gothic UI", 9F);
            dtpBirthDate.Location = new Point(161, 398);
            dtpBirthDate.Name = "dtpBirthDate";
            dtpBirthDate.Size = new Size(647, 37);
            dtpBirthDate.TabIndex = 30;
            // 
            // txtCaseStatus
            // 
            txtCaseStatus.Location = new Point(162, 632);
            txtCaseStatus.Multiline = true;
            txtCaseStatus.Name = "txtCaseStatus";
            txtCaseStatus.Size = new Size(647, 28);
            txtCaseStatus.TabIndex = 28;
            // 
            // txtLanguages
            // 
            txtLanguages.Location = new Point(162, 581);
            txtLanguages.Multiline = true;
            txtLanguages.Name = "txtLanguages";
            txtLanguages.Size = new Size(646, 32);
            txtLanguages.TabIndex = 27;
            // 
            // txtDistinctiveMarks
            // 
            txtDistinctiveMarks.Location = new Point(224, 536);
            txtDistinctiveMarks.Multiline = true;
            txtDistinctiveMarks.Name = "txtDistinctiveMarks";
            txtDistinctiveMarks.Size = new Size(584, 29);
            txtDistinctiveMarks.TabIndex = 26;
            // 
            // txtLastAddress
            // 
            txtLastAddress.Location = new Point(162, 450);
            txtLastAddress.Multiline = true;
            txtLastAddress.Name = "txtLastAddress";
            txtLastAddress.Size = new Size(646, 28);
            txtLastAddress.TabIndex = 24;
            // 
            // txtBirthPlace
            // 
            txtBirthPlace.Location = new Point(161, 353);
            txtBirthPlace.Multiline = true;
            txtBirthPlace.Name = "txtBirthPlace";
            txtBirthPlace.Size = new Size(647, 30);
            txtBirthPlace.TabIndex = 22;
            // 
            // txtCitizenship
            // 
            txtCitizenship.Location = new Point(162, 297);
            txtCitizenship.Multiline = true;
            txtCitizenship.Name = "txtCitizenship";
            txtCitizenship.Size = new Size(647, 33);
            txtCitizenship.TabIndex = 21;
            // 
            // txtHairColor
            // 
            txtHairColor.Location = new Point(563, 250);
            txtHairColor.Multiline = true;
            txtHairColor.Name = "txtHairColor";
            txtHairColor.Size = new Size(245, 28);
            txtHairColor.TabIndex = 20;
            // 
            // txtEyeColor
            // 
            txtEyeColor.Location = new Point(162, 254);
            txtEyeColor.Multiline = true;
            txtEyeColor.Name = "txtEyeColor";
            txtEyeColor.Size = new Size(243, 28);
            txtEyeColor.TabIndex = 19;
            // 
            // txtHeight
            // 
            txtHeight.Location = new Point(162, 201);
            txtHeight.Multiline = true;
            txtHeight.Name = "txtHeight";
            txtHeight.Size = new Size(647, 30);
            txtHeight.TabIndex = 18;
            // 
            // txtNickname
            // 
            txtNickname.Location = new Point(162, 152);
            txtNickname.Multiline = true;
            txtNickname.Name = "txtNickname";
            txtNickname.Size = new Size(647, 31);
            txtNickname.TabIndex = 17;
            // 
            // txtFirstName
            // 
            txtFirstName.Location = new Point(162, 101);
            txtFirstName.Multiline = true;
            txtFirstName.Name = "txtFirstName";
            txtFirstName.Size = new Size(647, 31);
            txtFirstName.TabIndex = 16;
            // 
            // txtLastName
            // 
            txtLastName.Location = new Point(162, 56);
            txtLastName.Multiline = true;
            txtLastName.Name = "txtLastName";
            txtLastName.Size = new Size(647, 29);
            txtLastName.TabIndex = 15;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Font = new Font("Yu Gothic UI", 10F);
            label15.Location = new Point(24, 683);
            label15.Name = "label15";
            label15.Size = new Size(63, 28);
            label15.TabIndex = 14;
            label15.Text = "Gang:";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Yu Gothic UI", 10F);
            label14.Location = new Point(22, 632);
            label14.Name = "label14";
            label14.Size = new Size(115, 28);
            label14.TabIndex = 13;
            label14.Text = "Case Status:";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Yu Gothic UI", 10F);
            label13.Location = new Point(22, 585);
            label13.Name = "label13";
            label13.Size = new Size(109, 28);
            label13.TabIndex = 12;
            label13.Text = "Languages:";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Yu Gothic UI", 10F);
            label12.Location = new Point(24, 540);
            label12.Name = "label12";
            label12.Size = new Size(165, 28);
            label12.TabIndex = 11;
            label12.Text = "Distinctive Marks:";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Yu Gothic UI", 10F);
            label11.Location = new Point(24, 493);
            label11.Name = "label11";
            label11.Size = new Size(132, 28);
            label11.TabIndex = 10;
            label11.Text = "Cr. Profession:";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Yu Gothic UI", 10F);
            label10.Location = new Point(22, 450);
            label10.Name = "label10";
            label10.Size = new Size(125, 28);
            label10.TabIndex = 9;
            label10.Text = "Last Address:";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Yu Gothic UI", 10F);
            label9.Location = new Point(20, 407);
            label9.Name = "label9";
            label9.Size = new Size(103, 28);
            label9.TabIndex = 8;
            label9.Text = "Birth Date:";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Yu Gothic UI", 10F);
            label8.Location = new Point(24, 357);
            label8.Name = "label8";
            label8.Size = new Size(107, 28);
            label8.TabIndex = 7;
            label8.Text = "Birth Place:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Yu Gothic UI", 10F);
            label7.Location = new Point(22, 297);
            label7.Name = "label7";
            label7.Size = new Size(111, 28);
            label7.TabIndex = 6;
            label7.Text = "Citizenship:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Yu Gothic UI", 10F);
            label6.Location = new Point(426, 254);
            label6.Name = "label6";
            label6.Size = new Size(105, 28);
            label6.TabIndex = 5;
            label6.Text = "Hair Color:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Yu Gothic UI", 10F);
            label5.Location = new Point(24, 254);
            label5.Name = "label5";
            label5.Size = new Size(99, 28);
            label5.TabIndex = 4;
            label5.Text = "Eye Color:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Yu Gothic UI", 10F);
            label4.Location = new Point(24, 205);
            label4.Name = "label4";
            label4.Size = new Size(75, 28);
            label4.TabIndex = 3;
            label4.Text = "Height:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Yu Gothic UI", 10F);
            label3.Location = new Point(24, 152);
            label3.Name = "label3";
            label3.Size = new Size(103, 28);
            label3.TabIndex = 2;
            label3.Text = "Nickname:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Yu Gothic UI", 10F);
            label2.Location = new Point(20, 101);
            label2.Name = "label2";
            label2.Size = new Size(110, 28);
            label2.TabIndex = 1;
            label2.Text = "First Name:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Yu Gothic UI", 10F);
            label1.Location = new Point(23, 56);
            label1.Name = "label1";
            label1.Size = new Size(107, 28);
            label1.TabIndex = 0;
            label1.Text = "Last Name:";
            // 
            // btnSave
            // 
            btnSave.Location = new Point(142, 745);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(112, 34);
            btnSave.TabIndex = 1;
            btnSave.Text = "Save";
            btnSave.UseVisualStyleBackColor = true;
            btnSave.Click += btnSave_Click;
            // 
            // btnCancel
            // 
            btnCancel.Location = new Point(584, 745);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(112, 34);
            btnCancel.TabIndex = 2;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = true;
            btnCancel.Click += btnCancel_Click_1;
            // 
            // CriminalForm
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(916, 836);
            Controls.Add(btnCancel);
            Controls.Add(btnSave);
            Controls.Add(groupBox1);
            Name = "CriminalForm";
            Text = "CriminalForm";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private Label label8;
        private Label label7;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private Label label12;
        private Label label11;
        private Label label10;
        private Label label9;
        private TextBox txtLastName;
        private Label label15;
        private Label label14;
        private Label label13;
        private TextBox txtLastAddress;
        private TextBox txtBirthPlace;
        private TextBox txtCitizenship;
        private TextBox txtHairColor;
        private TextBox txtEyeColor;
        private TextBox txtHeight;
        private TextBox txtNickname;
        private TextBox txtFirstName;
        private TextBox txtCaseStatus;
        private TextBox txtLanguages;
        private TextBox txtDistinctiveMarks;
        private Button btnSave;
        private Button btnCancel;
        private DateTimePicker dtpBirthDate;
        private ComboBox cmbProfession;
        private TextBox txtGang;
    }
}