﻿namespace Course_Work_OOP_Yeromenko
{
    partial class DetailsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            cmbProfession = new ComboBox();
            dtpBirthDate = new DateTimePicker();
            txtCaseStatus = new TextBox();
            txtLanguages = new TextBox();
            txtDistinctiveMarks = new TextBox();
            txtLastAddress = new TextBox();
            txtBirthPlace = new TextBox();
            txtCitizenship = new TextBox();
            txtHairColor = new TextBox();
            txtEyeColor = new TextBox();
            txtHeight = new TextBox();
            txtNickname = new TextBox();
            txtName = new TextBox();
            txtLastName = new TextBox();
            lblGang = new Label();
            lblCaseStatus = new Label();
            lblLanguages = new Label();
            lblDistinctiveMarks = new Label();
            lblCriminalProfession = new Label();
            lblLastAddress = new Label();
            lblBirthDate = new Label();
            lblBirthPlace = new Label();
            lblCitizenship = new Label();
            lblHairColor = new Label();
            lblEyeColor = new Label();
            lblHeight = new Label();
            lblNickname = new Label();
            lblName = new Label();
            lblLastName = new Label();
            btnClose = new Button();
            btnSave = new Button();
            btnEdit = new Button();
            txtGang = new TextBox();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(txtGang);
            groupBox1.Controls.Add(cmbProfession);
            groupBox1.Controls.Add(dtpBirthDate);
            groupBox1.Controls.Add(txtCaseStatus);
            groupBox1.Controls.Add(txtLanguages);
            groupBox1.Controls.Add(txtDistinctiveMarks);
            groupBox1.Controls.Add(txtLastAddress);
            groupBox1.Controls.Add(txtBirthPlace);
            groupBox1.Controls.Add(txtCitizenship);
            groupBox1.Controls.Add(txtHairColor);
            groupBox1.Controls.Add(txtEyeColor);
            groupBox1.Controls.Add(txtHeight);
            groupBox1.Controls.Add(txtNickname);
            groupBox1.Controls.Add(txtName);
            groupBox1.Controls.Add(txtLastName);
            groupBox1.Controls.Add(lblGang);
            groupBox1.Controls.Add(lblCaseStatus);
            groupBox1.Controls.Add(lblLanguages);
            groupBox1.Controls.Add(lblDistinctiveMarks);
            groupBox1.Controls.Add(lblCriminalProfession);
            groupBox1.Controls.Add(lblLastAddress);
            groupBox1.Controls.Add(lblBirthDate);
            groupBox1.Controls.Add(lblBirthPlace);
            groupBox1.Controls.Add(lblCitizenship);
            groupBox1.Controls.Add(lblHairColor);
            groupBox1.Controls.Add(lblEyeColor);
            groupBox1.Controls.Add(lblHeight);
            groupBox1.Controls.Add(lblNickname);
            groupBox1.Controls.Add(lblName);
            groupBox1.Controls.Add(lblLastName);
            groupBox1.Location = new Point(22, 12);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(755, 594);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Criminal Details";
            // 
            // cmbProfession
            // 
            cmbProfession.FormattingEnabled = true;
            cmbProfession.Location = new Point(148, 397);
            cmbProfession.Name = "cmbProfession";
            cmbProfession.Size = new Size(557, 33);
            cmbProfession.TabIndex = 31;
            // 
            // dtpBirthDate
            // 
            dtpBirthDate.Location = new Point(148, 323);
            dtpBirthDate.Name = "dtpBirthDate";
            dtpBirthDate.Size = new Size(557, 31);
            dtpBirthDate.TabIndex = 30;
            // 
            // txtCaseStatus
            // 
            txtCaseStatus.Location = new Point(148, 510);
            txtCaseStatus.Name = "txtCaseStatus";
            txtCaseStatus.Size = new Size(557, 31);
            txtCaseStatus.TabIndex = 28;
            // 
            // txtLanguages
            // 
            txtLanguages.Location = new Point(148, 473);
            txtLanguages.Name = "txtLanguages";
            txtLanguages.Size = new Size(557, 31);
            txtLanguages.TabIndex = 27;
            // 
            // txtDistinctiveMarks
            // 
            txtDistinctiveMarks.Location = new Point(188, 437);
            txtDistinctiveMarks.Name = "txtDistinctiveMarks";
            txtDistinctiveMarks.Size = new Size(517, 31);
            txtDistinctiveMarks.TabIndex = 26;
            // 
            // txtLastAddress
            // 
            txtLastAddress.Location = new Point(148, 360);
            txtLastAddress.Name = "txtLastAddress";
            txtLastAddress.Size = new Size(557, 31);
            txtLastAddress.TabIndex = 24;
            // 
            // txtBirthPlace
            // 
            txtBirthPlace.Location = new Point(148, 286);
            txtBirthPlace.Name = "txtBirthPlace";
            txtBirthPlace.Size = new Size(557, 31);
            txtBirthPlace.TabIndex = 22;
            // 
            // txtCitizenship
            // 
            txtCitizenship.Location = new Point(148, 246);
            txtCitizenship.Name = "txtCitizenship";
            txtCitizenship.Size = new Size(557, 31);
            txtCitizenship.TabIndex = 21;
            // 
            // txtHairColor
            // 
            txtHairColor.Location = new Point(148, 209);
            txtHairColor.Name = "txtHairColor";
            txtHairColor.Size = new Size(557, 31);
            txtHairColor.TabIndex = 20;
            // 
            // txtEyeColor
            // 
            txtEyeColor.Location = new Point(148, 173);
            txtEyeColor.Name = "txtEyeColor";
            txtEyeColor.Size = new Size(557, 31);
            txtEyeColor.TabIndex = 19;
            // 
            // txtHeight
            // 
            txtHeight.Location = new Point(148, 137);
            txtHeight.Name = "txtHeight";
            txtHeight.Size = new Size(557, 31);
            txtHeight.TabIndex = 18;
            // 
            // txtNickname
            // 
            txtNickname.Location = new Point(148, 103);
            txtNickname.Name = "txtNickname";
            txtNickname.Size = new Size(557, 31);
            txtNickname.TabIndex = 17;
            // 
            // txtName
            // 
            txtName.Location = new Point(148, 67);
            txtName.Name = "txtName";
            txtName.Size = new Size(557, 31);
            txtName.TabIndex = 16;
            // 
            // txtLastName
            // 
            txtLastName.Location = new Point(148, 30);
            txtLastName.Name = "txtLastName";
            txtLastName.Size = new Size(557, 31);
            txtLastName.TabIndex = 15;
            // 
            // lblGang
            // 
            lblGang.AutoSize = true;
            lblGang.Location = new Point(40, 556);
            lblGang.Name = "lblGang";
            lblGang.Size = new Size(58, 25);
            lblGang.TabIndex = 14;
            lblGang.Text = "Gang:";
            // 
            // lblCaseStatus
            // 
            lblCaseStatus.AutoSize = true;
            lblCaseStatus.Location = new Point(35, 519);
            lblCaseStatus.Name = "lblCaseStatus";
            lblCaseStatus.Size = new Size(105, 25);
            lblCaseStatus.TabIndex = 13;
            lblCaseStatus.Text = "Case status:";
            // 
            // lblLanguages
            // 
            lblLanguages.AutoSize = true;
            lblLanguages.Location = new Point(34, 479);
            lblLanguages.Name = "lblLanguages";
            lblLanguages.Size = new Size(101, 25);
            lblLanguages.TabIndex = 12;
            lblLanguages.Text = "Languages:";
            // 
            // lblDistinctiveMarks
            // 
            lblDistinctiveMarks.AutoSize = true;
            lblDistinctiveMarks.Location = new Point(32, 443);
            lblDistinctiveMarks.Name = "lblDistinctiveMarks";
            lblDistinctiveMarks.Size = new Size(150, 25);
            lblDistinctiveMarks.TabIndex = 11;
            lblDistinctiveMarks.Text = "Distinctive marks:";
            // 
            // lblCriminalProfession
            // 
            lblCriminalProfession.AutoSize = true;
            lblCriminalProfession.Location = new Point(34, 406);
            lblCriminalProfession.Name = "lblCriminalProfession";
            lblCriminalProfession.Size = new Size(99, 25);
            lblCriminalProfession.TabIndex = 10;
            lblCriminalProfession.Text = "Profession:";
            // 
            // lblLastAddress
            // 
            lblLastAddress.AutoSize = true;
            lblLastAddress.Location = new Point(35, 368);
            lblLastAddress.Name = "lblLastAddress";
            lblLastAddress.Size = new Size(103, 25);
            lblLastAddress.TabIndex = 9;
            lblLastAddress.Text = "Last adress:";
            // 
            // lblBirthDate
            // 
            lblBirthDate.AutoSize = true;
            lblBirthDate.Location = new Point(32, 331);
            lblBirthDate.Name = "lblBirthDate";
            lblBirthDate.Size = new Size(88, 25);
            lblBirthDate.TabIndex = 8;
            lblBirthDate.Text = "Birth date";
            // 
            // lblBirthPlace
            // 
            lblBirthPlace.AutoSize = true;
            lblBirthPlace.Location = new Point(32, 292);
            lblBirthPlace.Name = "lblBirthPlace";
            lblBirthPlace.Size = new Size(98, 25);
            lblBirthPlace.TabIndex = 7;
            lblBirthPlace.Text = "Birth place:";
            // 
            // lblCitizenship
            // 
            lblCitizenship.AutoSize = true;
            lblCitizenship.Location = new Point(32, 253);
            lblCitizenship.Name = "lblCitizenship";
            lblCitizenship.Size = new Size(101, 25);
            lblCitizenship.TabIndex = 6;
            lblCitizenship.Text = "Citizenship:";
            // 
            // lblHairColor
            // 
            lblHairColor.AutoSize = true;
            lblHairColor.Location = new Point(35, 215);
            lblHairColor.Name = "lblHairColor";
            lblHairColor.Size = new Size(93, 25);
            lblHairColor.TabIndex = 5;
            lblHairColor.Text = "Hair color:";
            // 
            // lblEyeColor
            // 
            lblEyeColor.AutoSize = true;
            lblEyeColor.Location = new Point(32, 179);
            lblEyeColor.Name = "lblEyeColor";
            lblEyeColor.Size = new Size(88, 25);
            lblEyeColor.TabIndex = 4;
            lblEyeColor.Text = "Eye color:";
            // 
            // lblHeight
            // 
            lblHeight.AutoSize = true;
            lblHeight.Location = new Point(32, 143);
            lblHeight.Name = "lblHeight";
            lblHeight.Size = new Size(69, 25);
            lblHeight.TabIndex = 3;
            lblHeight.Text = "Height:";
            // 
            // lblNickname
            // 
            lblNickname.AutoSize = true;
            lblNickname.Location = new Point(32, 109);
            lblNickname.Name = "lblNickname";
            lblNickname.Size = new Size(94, 25);
            lblNickname.TabIndex = 2;
            lblNickname.Text = "Nickname:";
            // 
            // lblName
            // 
            lblName.AutoSize = true;
            lblName.Location = new Point(35, 73);
            lblName.Name = "lblName";
            lblName.Size = new Size(63, 25);
            lblName.TabIndex = 1;
            lblName.Text = "Name:";
            // 
            // lblLastName
            // 
            lblLastName.AutoSize = true;
            lblLastName.Location = new Point(32, 36);
            lblLastName.Name = "lblLastName";
            lblLastName.Size = new Size(96, 25);
            lblLastName.TabIndex = 0;
            lblLastName.Text = "Last name:";
            // 
            // btnClose
            // 
            btnClose.Location = new Point(556, 619);
            btnClose.Name = "btnClose";
            btnClose.Size = new Size(112, 34);
            btnClose.TabIndex = 1;
            btnClose.Text = "Close";
            btnClose.UseVisualStyleBackColor = true;
            btnClose.Click += btnClose_Click_1;
            // 
            // btnSave
            // 
            btnSave.Location = new Point(336, 619);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(112, 34);
            btnSave.TabIndex = 2;
            btnSave.Text = "Save";
            btnSave.UseVisualStyleBackColor = true;
            btnSave.Click += btnSave_Click;
            // 
            // btnEdit
            // 
            btnEdit.Location = new Point(112, 619);
            btnEdit.Name = "btnEdit";
            btnEdit.Size = new Size(112, 34);
            btnEdit.TabIndex = 3;
            btnEdit.Text = "Edit";
            btnEdit.UseVisualStyleBackColor = true;
            btnEdit.Click += btnEdit_Click;
            // 
            // txtGang
            // 
            txtGang.Location = new Point(148, 550);
            txtGang.Name = "txtGang";
            txtGang.Size = new Size(557, 31);
            txtGang.TabIndex = 32;
            // 
            // DetailsForm
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 665);
            Controls.Add(btnEdit);
            Controls.Add(btnSave);
            Controls.Add(btnClose);
            Controls.Add(groupBox1);
            Name = "DetailsForm";
            Text = "DetailsForm";
            Load += DetailsForm_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private Label lblName;
        private Label lblLastName;
        private Label lblLastAddress;
        private Label lblBirthDate;
        private Label lblBirthPlace;
        private Label lblCitizenship;
        private Label lblHairColor;
        private Label lblEyeColor;
        private Label lblHeight;
        private Label lblNickname;
        private Label lblGang;
        private Label lblCaseStatus;
        private Label lblLanguages;
        private Label lblDistinctiveMarks;
        private Label lblCriminalProfession;
        private Button btnClose;
        private TextBox txtNickname;
        private TextBox txtName;
        private TextBox txtLastName;
        private TextBox txtCaseStatus;
        private TextBox txtLanguages;
        private TextBox txtDistinctiveMarks;
        private TextBox txtLastAddress;
        private TextBox txtBirthPlace;
        private TextBox txtCitizenship;
        private TextBox txtHairColor;
        private TextBox txtEyeColor;
        private TextBox txtHeight;
        private Button btnSave;
        private Button btnEdit;
        private DateTimePicker dtpBirthDate;
        private ComboBox cmbProfession;
        private TextBox txtGang;
    }
}